﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse;
using Verse.AI;

namespace FeedingTube
{
    class Job_FillTube : JobDriver
    {
        private const TargetIndex tubeToFill = TargetIndex.A;
        private const TargetIndex foodToLoad = TargetIndex.B;
        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            if (!pawn.Reserve(job.GetTarget(foodToLoad), job, 1, job.GetTarget(foodToLoad).Thing.stackCount, null))
                return false;
            return true;
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(tubeToFill);
            this.FailOnForbidden(foodToLoad);
            yield return Toils_Goto.GotoThing(foodToLoad, PathEndMode.ClosestTouch).FailOnSomeonePhysicallyInteracting(foodToLoad).FailOnDespawnedNullOrForbidden(foodToLoad);
            job.count = job.GetTarget(foodToLoad).Thing.stackCount;
            yield return Toils_Haul.StartCarryThing(foodToLoad, false, true, false);
            yield return Toils_Goto.GotoThing(tubeToFill, PathEndMode.Touch);
            Toil curToil = null;
            curToil = Toils_General.Wait(240, TargetIndex.None).WithProgressBarToilDelay(TargetIndex.A, false, -0.5f).FailOn(delegate ()
            {
                Pawn actor = curToil.actor;
                Job curJob = actor.jobs.curJob;
                FeedingTube dest = curJob.GetTarget(tubeToFill).Thing as FeedingTube;
                if (dest is null)
                    return true;
                Thing food = curJob.GetTarget(foodToLoad).Thing;
                if (!dest.Storeable(food))
                    return true;
                if (dest.foodCount() >= FeedingTube.maxFoodStored)
                    return true;
                return false;
            });
            yield return curToil;
            curToil = new Toil{
                initAction = () => {
                    Pawn actor = curToil.actor;
                    Job curJob = actor.jobs.curJob;
                    FeedingTube dest = curJob.GetTarget(tubeToFill).Thing as FeedingTube;
                    if (dest is null)
                        return;
                    int max = (FeedingTube.maxFoodStored - dest.foodCount());
                    Thing food = curJob.GetTarget(foodToLoad).Thing;
                    if (max > food.stackCount)
                        dest.LoadFood(food);
                    else
                    {
                        Log.Message($"Having to split off: Max{FeedingTube.maxFoodStored} Cur{dest.foodCount()} Math{max}");
                        dest.LoadFood(food.SplitOff(max));
                    }
                }
            };
            yield return curToil;
        }
    }

    class WorkGiver_FillTube : WorkGiver_Scanner
    {
        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            return shouldSkipStatic(pawn);
        }

        public override Danger MaxPathDanger(Pawn pawn)
        {
            return Danger.Deadly;
        }
        
        public static bool shouldSkipStatic(Pawn pawn)
        {
            if (pawn.WorkTypeIsDisabled(WorkTypeDefOf.Hauling))
                return true;
            if (pawn.WorkTagIsDisabled(WorkTags.ManualDumb))
                return true;
            if (pawn.WorkTagIsDisabled(WorkTags.Hauling))
                return true;
            return (pawn.Faction != Faction.OfPlayer) && (!pawn.RaceProps.Humanlike);
        }

        public static Job generateFillJob(Pawn pawn, Thing t)
        {
            if (shouldSkipStatic(pawn))
                return null;
            if (!(t is FeedingTube))
                return null;
            FeedingTube tube = (FeedingTube)t;
            Predicate<Thing> validator = (Thing x) => !x.IsForbidden(pawn) && pawn.CanReserve(x, 1, -1, null, false) && tube.Storeable(x) && tube.foodCount() < FeedingTube.maxFoodStored;
            Thing food = GenClosest.ClosestThingReachable(pawn.Position, pawn.Map, ThingRequest.ForGroup(ThingRequestGroup.FoodSourceNotPlantOrTree), PathEndMode.ClosestTouch, TraverseParms.For(pawn, Danger.Deadly, TraverseMode.ByPawn, false), 9999f, validator, null, 0, -1, false, RegionType.Set_Passable, false);
            if (food is null)
                return null;
            Job job = new Job(FillTube_JobDefOf.FillTube, t, food);
            return job;
        }

        public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn)
        {
            return pawn.Map.listerThings.AllThings.Where(t => t is FeedingTube tube && tube.foodCount() < FeedingTube.maxFoodStored);
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            return generateFillJob(pawn, t);
        }
    }

    [DefOf]
    class FillTube_JobDefOf {
        public static JobDef FillTube;
    }
    [DefOf]
    class FillTube_WorkGiverDefOf
    {
        public static WorkGiverDef FillTube;
    }
}
